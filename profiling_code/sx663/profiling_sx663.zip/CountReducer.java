import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
public class CountReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
//public IntWritable sum = new IntWritable();
IntWritable sum = new IntWritable();

int temp = 0;
for(IntWritable value : values){
	temp+=value.get();
	}
sum.set(temp);
context.write(key, sum); 


}


} 
