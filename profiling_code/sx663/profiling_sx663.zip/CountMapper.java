import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper; 
public class CountMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{ 

String line = value.toString();

String [] words = line.split(",");
String nameloc = words[0].concat(",");
nameloc = nameloc.concat(words[words.length-2]);
nameloc = nameloc.concat(",");
nameloc = nameloc.concat(words[words.length-1]);
int count =1;
/*
nuevaline.concat(line);
String lalo = "";
if(line.indexOf('(') !=-1){
int indexOfFirstParenthesis = line.indexOf('(');
int indexOfSecondParenthesis = line.indexOf(')');
lalo.concat(line.substring(indexOfFirstParenthesis+1,indexOfSecondParenthesis));
}else{
	lalo.concat("0,0");//this is for entries that don't have lat or long
}

nuevaline.concat(lalo);
*/
context.write(new Text(nameloc), new IntWritable(count)); //writing name in key, rest in value
}
			
} 