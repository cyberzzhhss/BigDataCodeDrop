Note that these map-reduce jobs are among earlier attempts at properly profiling the datasets, and are not
used in the final version of the project. Our team has found hive to be a better platform than map-reduce for the cleaning and profiling steps of our datasets.

See the subdirectory /zs1113 under /profiling_code for the hive codes.