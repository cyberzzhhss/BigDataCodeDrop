import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
public class CleanReducer extends Reducer<Text, Text, Text, Text> {
public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
//public IntWritable sum = new IntWritable();
Text temp = new Text();
for(Text value : values){
	 temp = value;
	}
context.write(key,temp); 

}


} 
