import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper; 
public class CleanMapper extends Mapper<LongWritable, Text, Text, Text>{
public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{ 
//this mappers attempts to store only the "good" records, with their names in Key and the rest of the info in value
//we determine 'goodness' by whether the 10th entry reads "Violations were cited in the following area(s)."
String line = value.toString();

String[] entries = line.split(",");

if (entries[9].equals("Violations were cited in the following area(s).")){ //this is a good entry
String info = "";
for (int i =1; i< entries.length;i++){
	info = info +entries[i];
}
context.write(new Text(entries[1]), new Text(info)); //writing name in key, rest in value
}
			
}  //end of method
}  //end of class